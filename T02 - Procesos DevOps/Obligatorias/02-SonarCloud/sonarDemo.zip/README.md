# SonarQube Demo Project
Este proyecto contiene un sitio web estático simple con errores intencionados para demostrar la detección de problemas con SonarQube/SonarCloud.
