# Restrospective

Write down here all the issues, solutions and thoughts happening in the project

## Issues

## Best solutions

## Random
